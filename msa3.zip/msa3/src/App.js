import React from 'react';
import './App.css';
import Forms from './components/Forms'
import PopUps from './components/PopUps';
import Tabs from './components/Tabs';
import Title from './components/Title';

function App() {
 
  return (
    <div className="App">
      <Title/>
      
      
    </div>
  );
}

export default App;
