import React,{useState} from 'react'

function Tabs() {
    const [index, setIndex]= useState(0);
  return (
    <div className='Tabs'>
        <div className='tab-list'>
        <div className={`tab-head ${index===0?'active':null}`} onClick={()=>{setIndex(0)}}>Layout  </div><br/>
        <div className={`tab-head ${index===1?'active':null}`} onClick={()=>{setIndex(1)}}>Building </div>
        
        </div>
    <div className='tab-content' hidden={index!==0}> <img src='http://www.workspacesolutions.com/blog/wp-content/uploads/2017/11/office-layout.jpeg' height='500px'/></div>
    <div className='tab-content' hidden={index!==1}><img src='https://brick-inc.com/wp-content/uploads/2017/11/2015-telegraph_Cam2.jpg' height='500px'/></div>
    
    </div>
  )
}

export default Tabs 

