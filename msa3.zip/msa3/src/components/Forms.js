import React from 'react'

function Forms() {
  return (
    <div className='forms-container'>
      <form>
        <h2>Contact Us</h2>
        <input type='text' placeholder='Name' maxLength='25' required/><br/><br/>
        <select>
            <option>India (+91)</option>
            <option>USA (+21)</option>
            <option>UK (+41)</option>
        </select>
        <input type='text' placeholder='Mobile No.' required/><br/><br/>
        <input type='email' name='email' placeholder='Email' required/><br/><br/>
        
        <input type='text' placeholder='Address Line 1' required/><br/><br/>
        <input type='text' placeholder='Address Line 2'/><br/><br/>
        <select required>
            <option>Country 1</option>
            <option>Country 2</option>
            <option>Country 3</option>
        </select>
        <select>
            <option>State 1</option>
            <option>State 2</option>
            <option>State 3</option>
        </select><br/><br/>
        <textarea rows='4' cols='40' placeholder='Enter any other info. '/><br/><br/>
        <button className='send-btn' >Send Message</button>
      </form>
    </div>
  )
}

export default Forms
