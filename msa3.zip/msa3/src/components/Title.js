import React, {useState}  from 'react'
import PopUps from './PopUps';
import Forms from './Forms';
import Tabs from './Tabs';

function Title() {
    const [isOpen, setIsOpen]= useState(false);
    const togglePopup = ()=>{
      setIsOpen(!isOpen);
  
    }
  return (
    <div className='title-container'>
        <header>
        <img src='https://static.vecteezy.com/system/resources/previews/000/395/417/original/modern-company-logo-design-vector.jpg' height='40px' width='40px'/>
        <h1>Architecture Portfolio</h1>
        
        </header>
        <div className='enquiry-btn'>
        <button  onClick={togglePopup}>Enquiry</button>
        </div>
        
      {isOpen&&<PopUps handleClose={(togglePopup)}
      content={<div>
       <Forms/>
      </div>}
      />}
      <Tabs/>
      <footer>
        <p>
            Architecture Name<br/>
            Contact: xxxxxxxxx<br/>
            Address: xxxxxxxxx,<br/>
                     xxxxxxxxx<br/>
        </p>
      </footer>
    </div>
  )
}

export default Title
