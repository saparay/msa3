import React from 'react'

function PopUps(props) {
  
  return (
    <div className='pop-up-container'>
        <div className='box'>
        <button className='btn-close' onClick={props.handleClose}>x</button>
        {props.content}
        </div>
      
    </div>
  )
}

export default PopUps
